from pyspark.sql import SparkSession
from pyspark.sql.functions import col, isnan, when, count, min, max, mean, expr
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation

# Initialize Spark session
spark = SparkSession.builder.appName("nuclear_plant_analysis").getOrCreate()

# Load the dataset
df_spark = spark.read.csv('nuclear_plants_small_dataset.csv', header=True, inferSchema=True)

# Calculate missing values for each column
missing_values = df_spark.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df_spark.columns])

# Collect the results and print each column with its count of missing values
missing_values_collected = missing_values.collect()[0]
for col_name, missing_count in missing_values_collected.asDict().items():
    print(f"{col_name}: {missing_count} missing values")


def summary_stats(df, column_names):
    # Dictionary to store the statistics
    stats_dict = {}

    # Process each statistic
    for stat_function, stat_name in [(min, "min"), (max, "max"), (mean, "mean"), (expr, "median")]:
        stats_cols = []
        for c in column_names:
            if c != 'Status':
                # Handle column names with spaces
                safe_column = f'`{c}`' if ' ' in c else c
                if stat_name != "median":
                    stats_cols.append(stat_function(col(safe_column)).alias(c))
                else:
                    stats_cols.append(expr(f"percentile_approx({safe_column}, 0.5)").alias(c))

        stat_df = df.select(*stats_cols)
        stats_dict[stat_name] = stat_df.first().asDict()

    # Convert the dictionary to a Pandas DataFrame and transpose it
    stats_df = pd.DataFrame(stats_dict)

    # Transpose the DataFrame
    transposed_df = stats_df.transpose()

    return transposed_df

# Define column names to compute statistics on excluding 'Status'
columns_to_compute = [c for c in df_spark.columns if c != 'Status']

# Group the data
normal_data = df_spark.filter(df_spark.Status == 'Normal')
abnormal_data = df_spark.filter(df_spark.Status == 'Abnormal')

# Calculate summary statistics for each group
normal_stats = summary_stats(normal_data, columns_to_compute)
abnormal_stats = summary_stats(abnormal_data, columns_to_compute)

# Calculate and display summary statistics for each group
normal_stats_df = summary_stats(normal_data, columns_to_compute)
abnormal_stats_df = summary_stats(abnormal_data, columns_to_compute)

# File paths for the CSV files
normal_stats_csv_path = 'normal_stats.csv'  
abnormal_stats_csv_path = 'abnormal_stats.csv'  

# Export summary statistics to CSV files
normal_stats_df.to_csv(normal_stats_csv_path, index=True)
abnormal_stats_df.to_csv(abnormal_stats_csv_path, index=True)


# Convert the PySpark DataFrames to Pandas DataFrames
normal_pd = normal_data.toPandas()
abnormal_pd = abnormal_data.toPandas()

# Add a 'Group' column to each DataFrame
normal_pd['Group'] = 'Normal'
abnormal_pd['Group'] = 'Abnormal'

# Combine the two DataFrames into one
combined_pd = pd.concat([normal_pd, abnormal_pd])

# Plotting
# Set the aesthetics for the plots
sns.set(style="whitegrid")

# Loop through each feature and create a box plot
for column in [col for col in combined_pd.columns if col not in ['Status', 'Group']]:
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='Group', y=column, data=combined_pd)
    plt.title(f'Box Plot of {column} by Group')
    plt.show()


# Assemble the features into a single vector
feature_columns = [c for c in df_spark.columns if c != 'Status']
assembler = VectorAssembler(inputCols=feature_columns, outputCol="features")
assembled_df = assembler.transform(df_spark)

# Compute the correlation matrix
correlation_matrix = Correlation.corr(assembled_df, "features").head()[0]

# Convert the correlation matrix to a Pandas DataFrame
correlation_matrix_df = pd.DataFrame(correlation_matrix.toArray(), columns=feature_columns, index=feature_columns)

# Export the correlation matrix to a CSV file
correlation_matrix_csv_path = 'correlation_matrix.csv'  
correlation_matrix_df.to_csv(correlation_matrix_csv_path, index=True)