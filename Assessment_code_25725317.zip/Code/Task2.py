##imports
import csv
from collections import Counter
import datetime
from math import radians, cos, sin, asin, sqrt


## 1

def process_passenger_data(line):
    # Extract the departure airport from each record
    departure_airport = line[2]
    return departure_airport

def count_flights(data):
    # Count occurrences of each airport in the dataset
    return Counter(data)

def get_unused_airports(all_airports, used_airports):
    # Determine which airports are not in the used airports list
    return all_airports.difference(used_airports)

def analyze_airport_data(passenger_filepath, airport_filepath):
    # Read and process passenger data
    with open(passenger_filepath, mode='r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip the header
        departures = [process_passenger_data(row) for row in reader]

    # Aggregate flight counts
    flight_counts = count_flights(departures)

    # Gather all airport codes and handle rows with missing data
    all_airports = set()
    with open(airport_filepath, mode='r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip the header
        for row in reader:
            if len(row) > 1:  # Ensure the row has at least two elements
                all_airports.add(row[1])

    # Identify airports with no departures
    unused_airports = get_unused_airports(all_airports, flight_counts.keys())

    return flight_counts, unused_airports

# File paths
passenger_data_filepath = 'AComp_Passenger_data_no_error.csv'
airport_data_filepath = 'top30_airports_LatLong.csv'

# Execute the analysis
flights_from_each_airport, airports_not_used = analyze_airport_data(passenger_data_filepath, airport_data_filepath)

# Displaying the results
print("Number of Flights from Each Airport:")
for airport, count in flights_from_each_airport.items():
    print(f"Airport {airport}: {count} flights")

print("\nAirports with No Recorded Flights:")
for airport in airports_not_used:
    print(f"Airport {airport} had no flights")

## 2

# Function for converting Unix epoch time to HH:MM
def epoch_to_time(epoch):
    return datetime.datetime.fromtimestamp(int(epoch)).strftime('%H:%M')

# Function to process and aggregate flight data
def aggregate_flights(filepath):
    aggregated_data = {}

    with open(filepath, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)  # Read the header

        # Debug: Print the header to verify field names
        print("CSV Header:", header)

        for row in reader:
            # Ensure row has enough columns
            if len(row) < 6:
                continue

            # Extracting data using column indices
            fid, from_airport, to_airport, departure_epoch, flight_time = row[1], row[2], row[3], row[4], row[5]
            departure_time = epoch_to_time(departure_epoch)
            arrival_time = epoch_to_time(int(departure_epoch) + int(flight_time) * 60)

            if fid not in aggregated_data:
                aggregated_data[fid] = {
                    'num_passengers': 0, 
                    'departure': from_airport, 
                    'arrival': to_airport, 
                    'departure_time': departure_time, 
                    'arrival_time': arrival_time
                }
            aggregated_data[fid]['num_passengers'] += 1

    return aggregated_data

# File path for the CSV data
flight_data_path = 'AComp_Passenger_data_no_error.csv'

# Execute the function
aggregated_flight_data = aggregate_flights(flight_data_path)

# Display the results
for flight_id, info in aggregated_flight_data.items():
    print(f"Flight {flight_id}: {info['num_passengers']} passengers, From {info['departure']} To {info['arrival']}, Departure at {info['departure_time']}, Arrival at {info['arrival_time']}")

## 3

# Function to calculate the distance between two points in nautical miles
def haversine(lat1, lon1, lat2, lon2):
    # Convert latitude and longitude from degrees to radians
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])

    # Haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    nautical_miles = 3440 * c
    return nautical_miles

# Load airport coordinates with a check for row length
airport_coords = {}
with open('top30_airports_LatLong.csv', 'r') as file:
    reader = csv.reader(file)
    next(reader)  # Skip header
    for row in reader:
        if len(row) >= 4:  # Check if the row has at least 4 columns (for IATA code, lat, and lon)
            airport_code, lat, lon = row[1], float(row[2]), float(row[3])
            airport_coords[airport_code] = (lat, lon)

# Process flight data and calculate distances
passenger_miles = {}
with open('AComp_Passenger_data_no_error.csv', 'r') as file:
    reader = csv.reader(file)
    next(reader)  # Skip header
    for row in reader:
        if len(row) >= 6:  # Check if the row has at least 6 columns
            passenger_id, from_airport, to_airport = row[0], row[2], row[3]
            if from_airport in airport_coords and to_airport in airport_coords:
                lat1, lon1 = airport_coords[from_airport]
                lat2, lon2 = airport_coords[to_airport]
                distance = haversine(lat1, lon1, lat2, lon2)
                passenger_miles[passenger_id] = passenger_miles.get(passenger_id, 0) + distance

# Find the passenger with the highest miles
highest_miles_passenger = max(passenger_miles, key=passenger_miles.get)
highest_miles = passenger_miles[highest_miles_passenger]

print(f"The passenger with the highest air miles is {highest_miles_passenger} with {highest_miles:.2f} nautical miles.")
